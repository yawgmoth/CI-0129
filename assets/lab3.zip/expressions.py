

def is_valid_type(typea, typeb, types):
    if typea == typeb:
        return True 
    if typea in types:
        return is_valid_type(types[typea], typeb, types)
    return False

class World:
    def __init__(self, atoms, sets):
        self.atoms = atoms 
        self.sets = sets  
    def get_values(self, domain):
        return self.sets.get(domain, [])

class Expression:
    def models(self, world):
        return False
    def substitute(self, var, value):
        return self
    def get_change(self, world, approximate=False):
        return []
    def __repr__(self):
        return "Expression"
    def __str__(self):
        return repr(self)
    def check_var_types(self, predicates, types, variables, objects):
        return None
    

class Atom(Expression):
    def __init__(self, name, args):
        self.name = name 
        self.args = tuple(args)
    def models(self, world):
        return self in world.atoms
    def __eq__(self, other):
        return self.name == other.name and self.args == other.args
    def substitute(self, var, value):
        return Atom(self.name, map(lambda x: value if x == var else x, self.args))
    def __repr__(self):
        return "(" + self.name + " " + " ".join(self.args) + ")"
    def get_change(self, world, approximate=False):
        return [("add", self)]
    def __hash__(self):
        return hash((self.name, self.args))
    def check_var_types(self, predicates, types, variables, objects):
        if self.name in predicates:
            ptypes,pvars = predicates[self.name]
            for a,pv in zip(self.args,pvars):
                if a in variables:
                    if not is_valid_type(variables[a], ptypes[pv], types):
                        return "Parameter %s of predicate %s should have type %s, but actual parameter %s has incompatible type %s"%(pv, self.name, ptypes[pv], a, variables[a])
                elif a in objects:
                    if not is_valid_type(objects[a], ptypes[pv], types):
                        return "Parameter %s of predicate %s should have type %s, but actual parameter %s has incompatible type %s"%(pv, self.name, ptypes[pv], a, objects[a])
                else:
                    return "Parameter %s of predicate %s is neither a known object nor a declared parameter or variable"%(a, self.name)
        return None

OP_AND = 0
OP_OR = 1
OP_NOT = 2
OP_IMPLY = 3

OPERNAMES = {OP_AND: "and", OP_OR: "or", OP_NOT: "not", OP_IMPLY: "imply"}

class NonDeterministicActionError(Exception):
    pass

class Oper(Expression):
    def __init__(self, op, args):
        self.op = op
        self.args = tuple(args)
    def models(self, world):
        if self.op == OP_AND:
            return all(map(lambda a: a.models(world), self.args))
        elif self.op == OP_OR:
            return any(map(lambda a: a.models(world), self.args))
        elif self.op == OP_IMPLY:
            if self.args[0].models(world): return self.args[1].models(world)
            return True
        else:
            return not self.args[0].models(world)
    def substitute(self, var, value):
        return Oper(self.op, map(lambda x: x.substitute(var,value), self.args))
    def __repr__(self):
        return "(" + OPERNAMES[self.op] + " " +  " ".join(map(str, self.args)) + ")"
    def get_change(self, world, approximate=False):
        if self.op == OP_AND or (self.op in [OP_OR, OP_IMPLY] and approximate):
            result = []
            for arg in self.args:
                result.extend(arg.get_change(world, approximate))
            return result 
        elif self.op == OP_OR or self.op == OP_IMPLY:
            print("Action effect can not include OR or IMPLIES")
            raise NonDeterministicActionError
        else:
            inner = self.args[0].get_change(world, approximate)
            result = []
            for (ch,expr) in inner:
                if ch == "add":
                    result.append(("del", expr))
                else:
                    result.append(("add", expr))
            return result
    def check_var_types(self, predicates, types, variables, objects):
        for arg in self.args:
            mismatch = arg.check_var_types(predicates, types, variables, objects)
            if mismatch:
                return mismatch
        return None
            
def subst(val, var, sub):
    if val == var: return sub
    return val
            
class Equals(Expression):
    def __init__(self, a, b):
        self.a = a
        self.b = b
    def models(self, world):
        return self.a == self.b
    def substitute(self, var, value):
        return Equals(subst(self.a, var, value), subst(self.b, var, value))
    def get_change(self, world, approximate=False):
        return []
    def __repr__(self):
        return "(= %s %s)"%(self.a,self.b)
    def __str__(self):
        return repr(self)
            
QUANT_EXISTS = 0
QUANT_FORALL = 1

QUANTNAMES = {QUANT_EXISTS: "exists", QUANT_FORALL: "forall"}
            
class Quantifier(Expression):
    def __init__(self, q, var, domain, arg):
        self.q = q
        self.var = var 
        self.domain = domain
        self.arg = arg
    def models(self, world):
        values = world.get_values(self.domain)
        if self.q == QUANT_EXISTS:
            return any(map(lambda v: self.arg.substitute(self.var, v).models(world), values))
        else:
            return all(map(lambda v: self.arg.substitute(self.var, v).models(world), values))
    def substitute(self, var, value):
        return Quantifier(self.q, self.var, self.domain, self.arg.substitute(var, value))
    def __repr__(self):
        return "(" + QUANTNAMES[self.q] + " (%s - %s) "%(self.var, self.domain)  +  str(self.arg) + ")"
    def get_change(self, world, approximate=False):
        if self.q == QUANT_FORALL or approximate:
            values = world.get_values(self.domain)
            result = []
            for v in values:
                result.extend(self.arg.substitute(self.var, v).get_change(world, approximate))
            return result
        raise NonDeterministicActionError
    def check_var_types(self, predicates, types, variables, objects):
        return self.arg.check_var_types(predicates, types, {**variables, self.var: self.domain}, objects)
        
class Conditional(Expression):
    def __init__(self, cond, arg):
        self.cond = cond
        self.arg = arg 
    def substitute(self, var, value):
        return Conditional(self.cond.substitute(var, value), self.arg.substitute(var, value))
    def __repr__(self):
        return "(when %s %s)"%(str(self.cond), str(self.arg))
    def get_change(self, world, approximate=False):
        if self.cond.models(world):
            return self.arg.get_change(world, approximate)
        return []
    def check_var_types(self, predicates, types, variables, objects):
        mismatch = self.cond.check_var_types(predicates, types, variables, objects)
        if mismatch:
            return mismatch
        return self.arg.check_var_types(predicates, types, variables, objects)


def make_expression(ast):
    """
    This function receives a sequence (list or tuple) representing the abstract syntax tree of a logical expression and returns an expression object suitable for further processing.
    
    In the Abstract Syntax Tree, the first element of the sequence is the operator (if applicable), with the subsequent items being the arguments to that operatior. The possible operators are:
    
       - "and" with *arbitrarily many parameters*
       - "or" with *arbitrarily many parameters*
       - "not" with exactly one parameter 
       - "=" with exactly two parameters which are variables or constants
       - "imply" with exactly two parameters 
       - "when" with exactly two parameters 
       - "exists" with exactly two parameters, where the first one is a variable specification
       - "forall" with exactly two parameters, where the first one is a variable specification
    
    Unless otherwise noted parameters may be, in turn, arbitrary expressions. Variable specifications are sequences of one or three elements:
       - A variable specification of the form ("?s", "-", "Stories") refers to a variable with name "?s", which is an element of the set "Stories"
       - A variable specification of the form ("?s",) refers to a variable with name "?s" with no type 
       
    If the first element of the passed sequence is not a parameter name, it can be assumed to be the name of a predicate in an atomic expression. In this case, 
    the remaining elements are the parameters, which may be constants or variables.
    
    An example for an abstract syntax tree corresponding to the expression 
          "forall s in stories: (murdermystery(s) imply (at(sherlock, bakerstreet) and not at(watson, bakerstreet) and at(body, crimescene)))" 
    would be (formatted for readability):
    
        ("forall", ("?s", "-", "Stories"), 
                   ("imply", 
                         ("murdermystery", "?s"),
                         ("and", 
                              ("at", "sherlock", "bakerstreet"),
                              ("not", 
                                   ("at", "watson", "bakerstreet")
                              ),
                              ("at", "body", "crimescene")
                         )
                   )
        )
    
    The return value of this function can be an arbitrary python object representing the expression, which will later be passed to the functions listed below. For notes on the "when" operator, 
    please refer to the documentation of the function "apply" below. Hint: A good way to represent logical formulas is to use objects that mirror the abstract syntax tree, e.g. an "And" object with 
    a "children" member, that then performs the operations described below.
    """
    if type(ast) != list:
        ast = ast.token
    op = ast[0]
    if op == "and":
        return Oper(OP_AND, map(make_expression, ast[1:]))
    elif op == "or":
        return Oper(OP_OR, map(make_expression, ast[1:]))
    elif op == "imply":
        return Oper(OP_IMPLY, map(make_expression, ast[1:]))
    elif op == "=":
        return Equals(ast[1].token, ast[2].token)
    elif op == "not":
        return Oper(OP_NOT, map(make_expression, ast[1:]))
    elif op == "when":
        return Conditional(make_expression(ast[1]), make_expression(ast[2]))
    elif op == "exists":
        return Quantifier(QUANT_EXISTS, ast[1].token[0].token, ast[1].token[2].token, make_expression(ast[2]))
    elif op == "forall":
        return Quantifier(QUANT_FORALL, ast[1].token[0].token, ast[1].token[2].token, make_expression(ast[2]))
    return Atom(ast[0].token, list(map(lambda t: t.token, ast[1:])))
    
def make_world(atoms, sets):
    """
    This function receives a list of atomic propositions, and a dictionary of sets and returns an object representing a logical world.
    
    The format of atoms passed to this function is identical to the atomic expressions passed to make_expression above, i.e. 
    the first element specifies the name of the predicate and the remaining elements are the parameters. For example 
       ("on", "a", "b") represents the atom "at(a, b)"
       
    The sets are passed as a dictionary, with the keys defining the names of all available sets, each mapping to a sequence of strings. 
    For example: {"people": ["holmes", "watson", "moriarty", "adler"], 
                  "stories": ["signoffour", "scandalinbohemia"], 
                  "": ["holmes", "watson", "moriarty", "adler", "signoffour", "scandalinbohemia"]}
                  
    The entry with the key "" contains all possible constants, and can be used if a variable is not given any particular domain.
    
    The world has to store these sets in order to allow the quantifiers forall and exists to use them. When evaluated, the forall operator from the 
    example above would look up the set "stories" in the world, and use the values found within to expand the formula.
    
    Similar to make_expression, this function returns an arbitrary python object that will only be used to pass to the functions below. Hint: It may be beneficial 
    to store the atoms in a set using the same representation as for atomic expressions, and the set dictioary as-is.
    """
    return World(set(map(make_expression, atoms)), sets)
    
def models(world, condition):
    """
    This function takes a world and a logical expression, and determines if the expression holds in the given world, i.e. if the world models the condition.
    
    The semantics of the logical operators are the usual ones, i.e. a world models an "and" expression if it models every child of the "and" expression, etc.
    For the quantifiers, when the world is constructed it is passed all possible sets, and the quantifiers will use this dictionary to determine their domain. 
    
    The special "when" operator is only used by the "apply" function (see below), and no world models it.
    
    The return value of this function should be True if the condition holds in the given world, and False otherwise.
    """
    return condition.models(world)
    
def substitute(expression, variable, value):
    """
    This function takes an expression, the name of a variable (usually starting with a question mark), and a constant value, and returns a *new* expression with all occurences of the variable 
    replaced with the value
    
    Do *not* replace the variable in-place, always return a new expression object. When you implement the quantifiers, you should use this same functionality to expand the formula to all possible 
    replacements for the variable that is quantified over.
    """
    return expression.substitute(variable, value)
    
def apply(world, effect):
    """
    This function takes a world, and an expression, and returns a new world, with the expression used to change the world. 
    
    For the effect you can assume the following restrictions:
       - The basic structure of the effect is a conjunction ("and") of modifications.
       - Each modification may be a literal (atom, or negation of an atom), a forall expression, or a when expression 
       - In the world produced by the application, positive literals should be added to the atoms of the world, and negative literals should be removed 
       - Forall expressions should be expanded by substituting the variable and processed recursively in the same way (the inner expression will only contain a conjunction of 
             literals, forall expressions, and when expressions as well)
       - "when" expressions have two parameters: A condition (which may be an arbitrary expression), and an effect, which follows the same restrictions (conjunction of literals, forall expressions and when expressions)
             The way "when" expressions are applied to a world depends on the condition: If the world models the condition (i.e. models(world, condition) is true, the effect is applied to the world. Otherwise, nothing happens.
             "when" expressions provide a nice, succinct way to define conditional effects, e.g. if someone is trying to open a door, the door will only open if it is unlocked.
             
    If an effect would cause the same atom to be set to true and to false, it should be set to false, i.e. removed from the set.
             
    The result of this function should be a *new* world, with the changes defined by the effect applied to the atoms, but with the same definition of sets as the original world. 
    
    Hint: If your world stores the atoms in a set, you can determine the change of the effect as two sets: an add set and a delete set, and get the atoms for the new world using basic set operations.
    """
    change = effect.get_change(world)
    mods = {"add": set(), "del": set()}
    for (mod,expr) in change:
        mods[mod].add(expr)
    return World((world.atoms | mods["add"]) - mods["del"], world.sets)



if __name__ == "__main__":
    exp = make_expression(("or", ("on", "a", "b"), ("on", "a", "d")))
    world = make_world([("on", "a", "b"), ("on", "b", "c"), ("on", "c", "d")], {})
    
    print("Should be True: ", end="")
    print(models(world, exp))
    change = make_expression(["and", ("not", ("on", "a", "b")), ("on", "a", "c")])
    
    print("Should be False: ", end="")
    print(models(apply(world, change), exp))
    
    
    print("mickey/minny example")
    world = make_world([("at", "store", "mickey"), ("at", "airport", "minny")], {"Locations": ["home", "park", "store", "airport", "theater"], "": ["home", "park", "store", "airport", "theater", "mickey", "minny"]})
    exp = make_expression(("and", 
        ("not", ("at", "park", "mickey")), 
        ("or", 
              ("at", "home", "mickey"), 
              ("at", "store", "mickey"), 
              ("at", "theater", "mickey"), 
              ("at", "airport", "mickey")), 
        ("imply", 
                  ("friends", "mickey", "minny"), 
                  ("forall", 
                            ("?l", "-", "Locations"),
                            ("imply",
                                    ("at", "?l", "mickey"),
                                    ("at", "?l", "minny"))))))
                                    
    print("Should be True: ", end="")
    print(models(world, exp))
    become_friends = make_expression(("friends", "mickey", "minny"))
    friendsworld = apply(world, become_friends)
    print("Should be False: ", end="")
    print(models(friendsworld, exp))
    move_minny = make_expression(("and", ("at", "store", "minny"), ("not", ("at", "airport", "minny"))))
    
    movedworld = apply(friendsworld, move_minny)
    print("Should be True: ", end="")
    print(models(movedworld, exp))
    
    
    move_both_cond = make_expression(("and", 
                                           ("at", "home", "mickey"), 
                                           ("not", ("at", "store", "mickey")), 
                                           ("when", 
                                                 ("at", "store", "minny"), 
                                                 ("and", 
                                                      ("at", "home", "minny"), 
                                                      ("not", ("at", "store", "minny"))))))
                                                      
    
    print("Should be True: ", end="")
    print(models(apply(movedworld, move_both_cond), exp))
    
    print("Should be False: ", end="")
    print(models(apply(friendsworld, move_both_cond), exp))
    
    exp1 = make_expression(("forall", 
                            ("?l", "-", "Locations"),
                            ("forall",
                                  ("?l1", "-", "Locations"),
                                  ("imply", 
                                       ("and", ("at", "?l", "mickey"),
                                               ("at", "?l1", "minny")),
                                       ("=", "?l", "?l1")))))
                                       
    print("Should be True: ", end="")
    print(models(apply(movedworld, move_both_cond), exp1))
    
    print("Should be False: ", end="")
    print(models(apply(friendsworld, move_both_cond), exp1))
