import sys
import graph
import expressions

START_FRAME = "START_FRAME"

class PDDLError(Exception):
    pass
    
class Token:
    def __init__(self,line,token):
        self.line = line
        self.token = token
    def __len__(self):
        return 2
    def __getitem__(self, idx):
        if idx == 0:
            return self.line
        elif idx == 1:
            return self.token 
        raise IndexError()
    def __setitem__(self, idx, value):
        if idx == 0:
            self.line = value
        elif idx == 1:
            self.token = value
        else:
            raise IndexError()
    def __eq__(self, other):
        if isinstance(other, str):
            return self.token == other
        return self.token == other.token
    def __iter__(self):
        raise Exception("Token is not iterable")
        

def parse_sexp(tokens):
    stack = []
    for tok in tokens:
        if tok.token == "(":
            stack.append(Token(tok.line,START_FRAME))
        elif tok.token == ")":
            current = []
            while stack[-1].token != START_FRAME:
                current.insert(0, stack.pop(-1))
                if not stack:
                    print("Extra closing parenthesis on line (or earlier)", i+1)
                    raise PDDLError()
            start = stack.pop(-1)
            stack.append(Token(start.line,current))
        else:
            stack.append(tok)
    if len(stack) > 1:
        missing = []
        for t in stack:
            if t.token == START_FRAME:
                missing.append(str(t.line))
        print("Missing closing parenthesis for parenthesis opening at line(s)", ",".join(missing))
        raise PDDLError()
    return stack[0]
    
def preprocess(fname):
    result = []
    f = open(fname)
    for i,l in enumerate(f):
        if not l.strip().startswith(";"):
            l = l.replace("(", " ( ").replace(")", " ) ")
            result.extend(map(lambda t: Token(i+1,t), l.lower().split()))
    return result
    
def make_parameters(tokens):
    result = {}
    current = []
    istype = False
    names = []
    for tok in tokens:
        t = tok.token
        if t == "-":
            istype = True
        elif not istype:
            current.append(t)
            names.append(t)
        else:
            for c in current:
                result[c] = t
            current = []
            istype = False
    for c in current:
        result[c] = ""
    return result,names
    

    
def make_operator(tokens, name):
    if tokens[0] != ":parameters":
        print("Action", name, "does not contain parameters as first element")
        raise PDDLError()
    (parameters,parameternames) = make_parameters(tokens[1].token)
    if tokens[2] != ":precondition":
        print("Action", name, "does not contain precondition as second element")
        raise PDDLError()
    precondition = expressions.make_expression(tokens[3].token)
    if tokens[4] != ":effect":
        print("Action", name, "does not contain effect as third element")
        raise PDDLError()
    effect = expressions.make_expression(tokens[5].token)
    return (parameters,parameternames,precondition,effect)
 

def make_sets(objs):
    result = {}
    for o in objs:
        if objs[o] not in result:
            result[objs[o]] = set()
        result[objs[o]].add(o)
    return result
    

    
def make_predicates(preds):
    result = {}
    for p in preds:
        result[p.token[0].token] = make_parameters(p.token[1:])
    return result
    
def parse_domain(fname):
    """
    Parses a PDDL domain file contained in the file fname
    
    The return value of this function is passed to planner.plan, and does not have to follow any particular format
    """
    tree = parse_sexp(preprocess(fname))[1]
    operators = {}
    objs = {}
    sets = {}
    types = {}
    predicates = {}
    for tok in tree:
        t = tok.token
        if type(t) == list:
            if t[0] == ":predicates":
                predicates = make_predicates(t[1:])
            elif t[0] == ":action":
                operators[t[1].token] = make_operator(t[2:], t[1].token)
            elif t[0] == ":constants":
                (objs,_) = make_parameters(t[1:])
                sets = make_sets(objs)
            elif t[0] == ":types":
                (types,_) = make_parameters(t[1:])
    sets[""] = set(objs.keys())        
    return (operators,objs,sets,types,predicates)
    
def parse_problem(fname):
    """
    Parses a PDDL problem file contained in the file fname
    
    The return value of this function is passed to planner.plan, and does not have to follow any particular format
    """
    tree = parse_sexp(preprocess(fname))[1]
    objs = {}
    sets = {}
    atoms = None
    goal = None
    for tok in tree:
        t = tok.token
        if type(t) == list:
            if t[0][1] == ":objects":
                (objs,objtypes) = make_parameters(t[1:])
                sets = make_sets(objs)
            elif t[0][1] == ":init":
                atoms = set(map(lambda tt: expressions.Atom(tt[1][0][1], list(map(lambda tx: tx[1], tt[1][1:]))), t[1:]))
            elif t[0][1] == ":goal":
                goal = expressions.make_expression(t[1][1])
    sets[""] = set(objs.keys())
    if goal is None:
        print("No goal defined")
        raise PDDLError
    if atoms is None:
        print("No initial state defined")
        raise PDDLError
    return (objs, sets, atoms, goal)
    
    
if __name__ == "__main__":
    print(parse_domain(sys.argv[1]))
    print(parse_problem(sys.argv[2]))

