import planner
import pddl
import traceback
import time
import multiprocessing

run = 0
passed = 0
MAXTIME = 600

def runplanner(domain, problem,useheuristic, cost, visited, expanded, error):
    try:
        (_,cost.value,visited.value,expanded.value) = planner.main(domain, problem, useheuristic) 
        error.value = 0
    except Exception:
        traceback.print_exc() 
    
class TestResult:
    def __init__(self, solved, cost=-1, visited=-1, expanded=-1, duration=MAXTIME, error=False):
        self.solved = solved
        self.cost = cost 
        self.visited = visited 
        self.expanded = expanded 
        self.duration = duration
        self.error = error
        
def runone(domain, problem, useheuristic):
    t0 = time.time()
    
    cost = multiprocessing.Value('d', 0)
    visited = multiprocessing.Value('d', 0)
    expanded = multiprocessing.Value('d', 0)
    error = multiprocessing.Value('d', 1)
    p = multiprocessing.Process(target=runplanner, args=(domain, problem, useheuristic, cost, visited, expanded, error))
    p.start()
    p.join(MAXTIME)
    if not p.is_alive():
        duration = time.time() - t0
        return TestResult(error.value == 0, cost.value, visited.value, expanded.value, duration, error.value)
    p.terminate()
    return TestResult(False)

def run_test_parse_domain(domain, parses=True):
    global run, passed 
    run += 1
    try:
        res = pddl.parse_domain(domain)
        if res is not None:
            if parses:
                passed += 1
            return parses
    except Exception:
        traceback.print_exc()
    if not parses:
        passed += 1
    return not parses
    
def run_test_parse_problem(problem, parses=True):
    global run, passed 
    run += 1
    try:
        res = pddl.parse_problem(problem)
        if res is not None:
            if parses:
                passed += 1
            return parses
    except Exception:
        traceback.print_exc()
    if not parses:
        passed += 1
    return not parses

def run_test_simple(domain, problem, result, h=False):
    global run, passed 
    run += 1
    try:
        t0 = time.time()
        res = runone(domain, problem, h)
        t1 = time.time()
        if not res.solved:
            return (False,res.cost,res.visited,res.expanded,t1-t0)
        else:
            passed += 1
            return (True,res.cost,res.visited,res.expanded,t1-t0)

    except Exception:
        traceback.print_exc()
    return (False,0,0,0,0)
    
def improvement(d,h):
    (ds,dc,dv,de,dt) = d
    (hs,hc,hv,he,ht) = h    
    return (dc-hc, dv-hv, de-he, dt-ht,ds,hs)

def main():
    global passed, run 
    
    results = {}
    results["parse elevator strips domain"] = run_test_parse_domain("tests/elevator_strips_domain.pddl")
    results["parse elevator strips problem 1"] = run_test_parse_problem("tests/elevator_strips_problem1.pddl")
    
    results["parse elevator adl domain"] = run_test_parse_domain("tests/elevator_adl_domain.pddl")
    results["parse elevator adl problem 1"] = run_test_parse_problem("tests/elevator_adl_problem1.pddl")
    
    results["parse logistics domain"] = run_test_parse_domain("tests/logistics_domain.pddl")
    results["parse logistics problem 1"] = run_test_parse_problem("tests/logistics_problem1.pddl")
    results["parse logistics problem 2"] = run_test_parse_problem("tests/logistics_problem2.pddl")
    
    results["plan elevator strips problem 1 d"] = run_test_simple("tests/elevator_strips_domain.pddl", "tests/elevator_strips_problem1.pddl", 4)
    results["plan elevator strips problem 1 h"] = run_test_simple("tests/elevator_strips_domain.pddl", "tests/elevator_strips_problem1.pddl", 4, True)
    results["improvement plan elevator strips problem 1"] = improvement(results["plan elevator strips problem 1 d"], results["plan elevator strips problem 1 h"])
    results["plan elevator strips problem 2 d"] = run_test_simple("tests/elevator_strips_domain.pddl", "tests/elevator_strips_problem2.pddl", 12)
    results["plan elevator strips problem 2 h"] = run_test_simple("tests/elevator_strips_domain.pddl", "tests/elevator_strips_problem2.pddl", 12, True)
    results["improvement plan elevator strips problem 2"] = improvement(results["plan elevator strips problem 2 d"], results["plan elevator strips problem 2 h"])
    
    results["plan elevator adl problem 1 d"] = run_test_simple("tests/elevator_adl_domain.pddl", "tests/elevator_adl_problem1.pddl", 4)
    results["plan elevator adl problem 1 h"] = run_test_simple("tests/elevator_adl_domain.pddl", "tests/elevator_adl_problem1.pddl", 4, True)
    results["improvement plan elevator adl problem 1"] = improvement(results["plan elevator adl problem 1 d"], results["plan elevator adl problem 1 h"])
    results["plan elevator adl problem 2 d"] = run_test_simple("tests/elevator_adl_domain.pddl", "tests/elevator_adl_problem2.pddl", 12)
    results["plan elevator adl problem 2 h"] = run_test_simple("tests/elevator_adl_domain.pddl", "tests/elevator_adl_problem2.pddl", 12, True)
    results["improvement plan elevator adl problem 2"] = improvement(results["plan elevator adl problem 2 d"], results["plan elevator adl problem 2 h"])
    results["plan elevator adl problem 3 d"] = run_test_simple("tests/elevator_adl_domain.pddl", "tests/elevator_adl_problem3.pddl", 12)
    results["plan elevator adl problem 3 h"] = run_test_simple("tests/elevator_adl_domain.pddl", "tests/elevator_adl_problem3.pddl", 12, True)
    results["improvement plan elevator adl problem 3"] = improvement(results["plan elevator adl problem 3 d"], results["plan elevator adl problem 3 h"])
    results["plan elevator adl problem 4 d"] = run_test_simple("tests/elevator_adl_domain.pddl", "tests/elevator_adl_problem4.pddl", 12)
    results["plan elevator adl problem 4 h"] = run_test_simple("tests/elevator_adl_domain.pddl", "tests/elevator_adl_problem4.pddl", 12, True)
    results["improvement plan elevator adl problem 4"] = improvement(results["plan elevator adl problem 4 d"], results["plan elevator adl problem 4 h"])
    
    results["plan elevator adl problem 5 d"] = run_test_simple("tests/elevator_adl_domain.pddl", "tests/elevator_adl_problem5.pddl", 12)
    results["plan elevator adl problem 5 h"] = run_test_simple("tests/elevator_adl_domain.pddl", "tests/elevator_adl_problem5.pddl", 12, True)
    results["improvement plan elevator adl problem 5"] = improvement(results["plan elevator adl problem 5 d"], results["plan elevator adl problem 5 h"])
    
    results["plan logistics problem 2 d"] = run_test_simple("tests/logistics_domain.pddl", "tests/logistics_problem2.pddl", 3)
    results["plan logistics problem 2 h"] = run_test_simple("tests/logistics_domain.pddl", "tests/logistics_problem2.pddl", 3, True)
    results["improvement plan logistics problem 2"] = improvement(results["plan logistics problem 2 d"], results["plan logistics problem 2 h"])
    results["plan logistics problem 3 d"] = run_test_simple("tests/logistics_domain.pddl", "tests/logistics_problem3.pddl", 11)
    results["plan logistics problem 3 h"] = run_test_simple("tests/logistics_domain.pddl", "tests/logistics_problem3.pddl", 11, True)
    results["improvement plan logistics problem 3"] = improvement(results["plan logistics problem 3 d"], results["plan logistics problem 3 h"])
    
    results["plan weird problem 1 d"] = run_test_simple("tests/weird_domain.pddl", "tests/weird_problem1.pddl", 1)
    results["plan weird problem 1 h"] = run_test_simple("tests/weird_domain.pddl", "tests/weird_problem1.pddl", 1, True)
    results["improvement plan weird problem 1"] = improvement(results["plan weird problem 1 d"], results["plan weird problem 1 h"])
    results["plan weird problem 2 d"] = run_test_simple("tests/weird_domain.pddl", "tests/weird_problem2.pddl", 3)
    results["plan weird problem 2 h"] = run_test_simple("tests/weird_domain.pddl", "tests/weird_problem2.pddl", 3, True)
    results["improvement plan weird problem 2"] = improvement(results["plan weird problem 2 d"], results["plan weird problem 2 h"])
    results["plan weird problem 3 d"] = run_test_simple("tests/weird_domain.pddl", "tests/weird_problem3.pddl", 7)
    results["plan weird problem 3 h"] = run_test_simple("tests/weird_domain.pddl", "tests/weird_problem3.pddl", 7, True)
    results["improvement plan weird problem 3"] = improvement(results["plan weird problem 3 d"], results["plan weird problem 3 h"])
    
    results["plan weird problem 3a d"] = run_test_simple("tests/weird_domain.pddl", "tests/weird_problem3a.pddl", 1)
    results["plan weird problem 3a h"] = run_test_simple("tests/weird_domain.pddl", "tests/weird_problem3a.pddl", 1, True)
    results["improvement plan weird problem 3a"] = improvement(results["plan weird problem 3a d"], results["plan weird problem 3a h"])
    
    results["plan tpp problem 3 d"] = run_test_simple("tests/tppdomain.pddl", "tests/tppp03.pddl", 1)
    results["plan tpp problem 3 h"] = run_test_simple("tests/tppdomain.pddl", "tests/tppp03.pddl", 1, True)
    results["improvement plan tpp problem 3"] = improvement(results["plan tpp problem 3 d"], results["plan tpp problem 3 h"])
    
    results["plan tpp problem 4 d"] = run_test_simple("tests/tppdomain.pddl", "tests/tppp04.pddl", 1)
    results["plan tpp problem 4 h"] = run_test_simple("tests/tppdomain.pddl", "tests/tppp04.pddl", 1, True)
    results["improvement plan tpp problem 4"] = improvement(results["plan tpp problem 4 d"], results["plan tpp problem 4 h"])
    
    results["plan psr small problem 5 d"] = run_test_simple("tests/psrp05-domain.pddl", "tests/psrp05-s9-n1-l4-f30.pddl", 1)
    results["plan psr small problem 5 h"] = run_test_simple("tests/psrp05-domain.pddl", "tests/psrp05-s9-n1-l4-f30.pddl", 1, True)
    results["improvement plan psr small problem 5"] = improvement(results["plan psr small problem 5 d"], results["plan psr small problem 5 h"])
    
    results["plan movie problem 5 d"] = run_test_simple("tests/moviedomain.pddl", "tests/movieprob05.pddl", 1)
    results["plan movie problem 5 h"] = run_test_simple("tests/moviedomain.pddl", "tests/movieprob05.pddl", 1, True)
    results["improvement plan movie problem 5"] = improvement(results["plan movie problem 5 d"], results["plan movie problem 5 h"])
    
    results["plan airport problem 3 d"] = run_test_simple("tests/p03-domain.pddl", "tests/p03-airport1-p2.pddl", 1)
    results["plan airport problem 3 h"] = run_test_simple("tests/p03-domain.pddl", "tests/p03-airport1-p2.pddl", 1, True)
    results["improvement plan airport problem 3"] = improvement(results["plan airport problem 3 d"], results["plan airport problem 3 h"])
    
    results["plan weird problem 3 reduced (when order 1)"] = run_test_simple("tests/weird_domain_reduced.pddl", "tests/weird_problem3a_reduced.pddl", 1)
    results["plan weird problem 3 reduced (when order 2)"] = run_test_simple("tests/weird_domain_reduced1.pddl", "tests/weird_problem3a_reduced.pddl", 1)

    print("passed %d of %d tests"%(passed, run))
    for t in results:
        if t.startswith("improvement"):
            print(t, results[t])
    
    
    
if __name__ == "__main__":
    main()   
