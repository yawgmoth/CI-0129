import time
import pddl
import graph
import expressions
import pathfinding
import sys 
import random

def addonly(changes):
    result = set()
    for ch in changes:
        if ch[0] == "add":
            result.add(ch[1])
    return result

class Action:
    def __init__(self, name, precondition, effect):
        self.name = name 
        self.precondition = precondition
        self.effect = effect
    def apply(self, world):
        if self.precondition.models(world):
            change = self.effect.get_change(world)
            mods = {"add": set(), "del": set()}
            for (mod,expr) in change:
                mods[mod].add(expr)
            return PlanningNode((world.atoms - mods["del"]) | mods["add"], world.sets, world.actions)
        else:
            return None
    def __hash__(self):
        return hash((self.name, self.precondition, self.effect))
    def __eq__(self, other):
        return self.name == other.name and self.precondition == other.precondition and self.effect == other.effect

class PlanningNode(graph.Node, expressions.World):
    def __init__(self, atoms, sets, actions):
        self.atoms = atoms
        self.sets = sets
        self.actions = actions 
    def get_id(self):
        return str(self.atoms)
    def get_neighbors(self):
        result = []
        for a in self.actions:
            new = a.apply(self)
            if new: 
                result.append(graph.Edge(new, 1, a.name))
        return result
        
class RelaxedAction:
    def __init__(self, action):
        self.action = action
    def apply(self, world):
        req = addonly(self.action.precondition.get_change(world, True))
        ch = addonly(self.action.effect.get_change(world, True))
        if req <= world.atoms:
            return ch
        else: 
            return None

        
def relaxed_graphplan(state, goalatoms):
    atoms = state.atoms.copy()
    #print("relaxed graphplan", len(state.actions))
    actions = list(map(RelaxedAction, state.actions))
    random.shuffle(actions)
    relstate = PlanningNode(atoms, state.sets, actions)
    steps = 0
    usedone = True
    while actions and not goalatoms <= relstate.atoms and usedone:
        newactions = []
        usedone = False
        for a in actions:
            ch = a.apply(relstate)
            if ch is None:
                newactions.append(a)
            else:
                usedone = True
                relstate.atoms |= ch
                if not goalatoms <= relstate.atoms:
                    steps += 1
        actions = newactions
    if not goalatoms <= relstate.atoms:
        return 10000
    return steps 
    
            
    
def all_assignments(paramnames, parameters, sets):
    if not paramnames:
        return[{}]
    inner = all_assignments(paramnames[1:], parameters, sets)
    result = []
    for val in sets[parameters[paramnames[0]]]:
        for i in inner:
            newi = i.copy()
            newi.update({paramnames[0]: val})
            result.append(newi)
    return result
    
    
def to_actions(sets, name, operator):
    (parameters,parameternames,precondition,effect) = operator
    assignments = all_assignments(list(parameters.keys()), parameters,sets)
    result = []
    for assignment in assignments:
        pre = precondition
        eff = effect
        for var in assignment:
            pre = pre.substitute(var, assignment[var])
            eff = eff.substitute(var, assignment[var])
        result.append(Action(name + "(" + ",".join(map(lambda v: "%s"%(assignment[v]), parameternames)) + ")", pre, eff))
    return result

def plan(domain, problem, useheuristic=True):
    """
    Find a solution to a planning problem in the given domain 
    
    The parameters domain and problem are exactly what is returned from pddl.parse_domain and pddl.parse_problem. If useheuristic is true,
    a planning heuristic (developed in task 4) should be used, otherwise use pathfinding.default_heuristic. This allows you to compare 
    the effect of your heuristic vs. the default one easily.
    
    The return value of this function should be a 4-tuple, with the exact same elements as returned by pathfinding.astar:
       - A plan, which is a sequence of graph.Edge objects that have to be traversed to reach a goal state from the start. Each Edge object represents an action, 
         and the edge's name should be the name of the action, consisting of the name of the operator the action was derived from, followed by the parenthesized 
         and comma-separated parameter values e.g. "move(agent-1,sq-1-1,sq-2-1)"
       - distance is the number of actions in the plan (i.e. each action has cost 1)
       - visited is the total number of nodes that were added to the frontier during the execution of the algorithm 
       - expanded is the total number of nodes that were expanded (i.e. whose neighbors were added to the frontier)
    """
    (operators, cobjects, csets,types,predicates) = domain
    (objects, sets, atoms, goal) = problem
    
    actions = []
    for op in operators:
        resolved = to_actions(sets, op, operators[op])
        actions.extend(resolved)
    start = PlanningNode(atoms, sets, actions)
    
    print("Starting planning process with", len(actions), "ground actions")
    
    def isgoal(node):
        return goal.models(node)
    
    goalatoms = addonly(goal.get_change(start, True))
    def planheuristic(node, action):
        return relaxed_graphplan(node, goalatoms)

    h = pathfinding.default_heuristic
    if useheuristic:
        h = planheuristic
    return pathfinding.astar(start, h, isgoal)
    
def validation(domain, problem):
    (operators, cobjects, csets,types,predicates) = domain
    (objects, sets, atoms, goal) = problem
    error = False
    for op in operators:
        mismatch = operators[op][2].check_var_types(predicates, types, operators[op][0], objects)
        if mismatch:
            print("Error in precondition of operator", op + ":", mismatch)
            error = True
        mismatch = operators[op][3].check_var_types(predicates, types, operators[op][0], objects)
        if mismatch:
            print("Error in effect of operator", op + ":", mismatch)
            error = True
    for a in atoms:
        mismatch = a.check_var_types(predicates, types, {}, objects)
        if mismatch:
            print("Error in initial state atom", str(a) + ":", mismatch)
            error = True
            
    mismatch = goal.check_var_types(predicates, types, {}, objects)
    if mismatch:
        print("Error in goal condition:", mismatch)
        error = True
    return error

def main(domainf, problemf, useheuristic):
    t0 = time.time()
    try:
        domain = pddl.parse_domain(domainf)
    except pddl.PDDLError:
        print("Could not parse PDDL domain file", domainf)
        return
    try:
        problem = pddl.parse_problem(problemf)
    except pddl.PDDLError:
        print("Could not parse PDDL problem file", problemf)
        return
    
    (operators, cobjects, csets,types,predicates) = domain
    (objects, sets, atoms, goal) = problem
    
    objects.update(cobjects)
    for s in csets:
        if s not in sets:
            sets[s] = csets[s]
        else:
            sets[s] |= csets[s]
    open = types
    while open:
        types = open
        open = {}
        for t in types:
            if types[t] not in sets:
                sets[types[t]] = set()
            if t in sets:
                sets[types[t]] |= sets[t]
            else:
                open[t] = types[t]

    if validation(domain,problem):
        print("Cannot start planning process, please fix these errors")
        return 
    try:
        (path,cost,visited_cnt,expanded_cnt) = plan(domain, problem, useheuristic)
    except expressions.NonDeterministicActionError:
        print("Could not perform planning procedure")
        return
    print("visited nodes:", visited_cnt, "expanded nodes:",expanded_cnt)
    if path is not None:
        print("Plan found with cost", cost)
        for n in path:
            print(n.name)
    else:
        print("No plan found")
    print("needed %.2f seconds"%(time.time() - t0))
    return (path,cost,visited_cnt,expanded_cnt)
    

if __name__ == "__main__":
    main(sys.argv[1], sys.argv[2], "-d" not in sys.argv)